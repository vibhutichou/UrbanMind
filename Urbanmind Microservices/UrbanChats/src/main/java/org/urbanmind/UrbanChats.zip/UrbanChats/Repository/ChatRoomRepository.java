package org.urbanmind.UrbanChats.Repository;



import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.urbanmind.UrbanChats.Entity.ChatRooms;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface ChatRoomRepository extends JpaRepository<ChatRooms, Long> {

    List<ChatRooms> findByUser1IdOrUser2Id(Long user1Id, Long user2Id);
    

    Page<ChatRooms> findByUser1IdOrUser2Id(
            Long user1Id,
            Long user2Id,
            Pageable pageable
    );

}


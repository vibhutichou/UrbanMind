package org.urbanmind.UrbanChats.websocket.handler;

import com.fasterxml.jackson.databind.ObjectMapper;

import org.urbanmind.UrbanChats.Entity.ChatMessage;
import org.urbanmind.UrbanChats.Service.ChatMessageService;
import org.urbanmind.UrbanChats.websocket.model.ChatSocketMessage;
import org.urbanmind.UrbanChats.websocket.registry.ChatSessionRegistry;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.*;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import java.time.OffsetDateTime;

@SuppressWarnings("unused")
@Component
public class ChatWebSocketHandler extends TextWebSocketHandler {

    private final ChatSessionRegistry sessionRegistry;
    private final ChatMessageService chatMessageService;
    
    private final ObjectMapper objectMapper;

    public ChatWebSocketHandler(ChatSessionRegistry sessionRegistry,
                                ChatMessageService chatMessageService,
                                ObjectMapper objectMapper) {
        this.sessionRegistry = sessionRegistry;
        this.chatMessageService = chatMessageService;
        this.objectMapper = objectMapper;
    }


    @Override
    public void afterConnectionEstablished(WebSocketSession session) {
        sessionRegistry.register(session);
    }

    @Override
    protected void handleTextMessage(WebSocketSession session, TextMessage message) throws Exception {

        try {
            ChatSocketMessage socketMessage =
                    objectMapper.readValue(message.getPayload(), ChatSocketMessage.class);

            ChatMessage savedMessage = chatMessageService.saveFromWebSocket(
                    socketMessage.getRoomId(),
                    socketMessage.getSenderUserId(),
                    socketMessage.getContent()
            );

            socketMessage.setCreatedAt(savedMessage.getCreatedAt());

            String payload = objectMapper.writeValueAsString(socketMessage);
            sessionRegistry.broadcastToRoom(socketMessage.getRoomId(), payload);

        } catch (Exception ex) {
            ex.printStackTrace(); // IMPORTANT
            session.sendMessage(new TextMessage(
                    "{\"error\":\"Message processing failed\"}"
            ));
        }
    }


    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) {
        sessionRegistry.remove(session);
    }
}
